/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_186()
{
    return 2425509967U;
}

void setval_262(unsigned *p)
{
    *p = 2428995912U;
}

void setval_194(unsigned *p)
{
    *p = 2496104776U;
}

unsigned addval_450(unsigned x)
{
    return x + 2425378960U;
}

unsigned addval_317(unsigned x)
{
    return x + 2425378848U;
}

void setval_245(unsigned *p)
{
    *p = 3281148152U;
}

unsigned addval_459(unsigned x)
{
    return x + 3284634056U;
}

unsigned getval_483()
{
    return 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_392(unsigned *p)
{
    *p = 3246993007U;
}

void setval_318(unsigned *p)
{
    *p = 3247494793U;
}

void setval_203(unsigned *p)
{
    *p = 4173584009U;
}

unsigned addval_158(unsigned x)
{
    return x + 3229931147U;
}

unsigned addval_396(unsigned x)
{
    return x + 3223377545U;
}

unsigned getval_380()
{
    return 3286239560U;
}

unsigned getval_379()
{
    return 2497743176U;
}

void setval_374(unsigned *p)
{
    *p = 1338229193U;
}

unsigned addval_216(unsigned x)
{
    return x + 2428602739U;
}

unsigned addval_232(unsigned x)
{
    return x + 3301097865U;
}

unsigned getval_175()
{
    return 3372799641U;
}

unsigned addval_215(unsigned x)
{
    return x + 3281046153U;
}

unsigned addval_466(unsigned x)
{
    return x + 2497743176U;
}

void setval_472(unsigned *p)
{
    *p = 3269495112U;
}

unsigned addval_202(unsigned x)
{
    return x + 3523791496U;
}

unsigned addval_237(unsigned x)
{
    return x + 2425536905U;
}

unsigned addval_331(unsigned x)
{
    return x + 2462746899U;
}

void setval_218(unsigned *p)
{
    *p = 3677929869U;
}

unsigned addval_395(unsigned x)
{
    return x + 3526937241U;
}

unsigned getval_249()
{
    return 2425476745U;
}

unsigned getval_366()
{
    return 3687110281U;
}

void setval_111(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_189()
{
    return 3250706057U;
}

unsigned addval_210(unsigned x)
{
    return x + 3269495112U;
}

void setval_443(unsigned *p)
{
    *p = 3281177225U;
}

unsigned addval_455(unsigned x)
{
    return x + 3524840073U;
}

unsigned getval_432()
{
    return 3375939993U;
}

void setval_350(unsigned *p)
{
    *p = 1623310729U;
}

unsigned getval_190()
{
    return 3767224473U;
}

unsigned addval_319(unsigned x)
{
    return x + 3286272328U;
}

void setval_182(unsigned *p)
{
    *p = 3380923017U;
}

unsigned getval_228()
{
    return 3523267209U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
