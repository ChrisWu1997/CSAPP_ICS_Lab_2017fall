//studentID = 1600012806 name = 吴润迪
//要求实现的模拟器只需要能模拟出hti/miss/eivction的次数
//而不需要存储实际数据
//关键点是建立缓存行的数据结构和相应功能函数
//特别注意LRU的实现需要每次调整相应的记录位 
#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <stdio.h>
#define MAXLRU 2000
int S, E, B;
int hit_count = 0, miss_count = 0, evict_count = 0;

//缓存行数据结构，LRU越大，表示越近访问 
typedef struct 
{
    int valid;
    int tag;
    int LRU;
}cacheline;
cacheline *mycache;

//打印help信息 
void print_help()
{
    printf("Usage: ./csim-ref [-hv] -s <s> -E <E> -b <b> -t <tracefile>"
    "-h: Optional help flag that prints usage info"
    "-v: Optional verbose flag that displays trace info"
    "-s <s>: Number of set index bits (S = 2s is the number of sets)"
    "-E <E>: Associativity (number of lines per set)"
    "-b <b>: Number of block bits (B = 2b is the block size)"
    "-t <tracefile>: Name of the valgrind trace to replay");
}

//从地址中获得set位 
int get_set(long addr, int s, int b)
{
    int mask = (1 << s) - 1;
    return (addr >> b) & mask;    
}

//从地址中获得tag位 
int get_tag(long addr, int s, int b)
{
    return addr >> (s + b);
}

//找到当前set中LRU最小的那一行 
int findMinLRU(cacheline *cache, int set)
{
    int minIndex = 0, minLRU = MAXLRU;
    cacheline *ptr = cache + set*E;
    for (int i = 0; i < E; ++i)
    {
        if ((ptr + i)->LRU < minLRU)
        {
            minIndex = i;
            minLRU = (ptr + i)->LRU;
        }
    }
    return minIndex;
}

//更新LRU记录位，当前访问的置为最大值，其余行均减一 
void updateLRU(cacheline *cache, int set, int hitIndex)
{
    cacheline *ptr = cache + set * E;
    for (int j = 0; j < E; ++j)
    {
        (ptr + j)->LRU--;
    }
    (ptr + hitIndex)->LRU = MAXLRU;
}

//访问是否不命中 
int isMiss(cacheline *cache, int set, int tag)
{
    int isMiss = 1;
    cacheline *ptr = cache + set * E;
    for (int i = 0; i < E; ++i)
    {
        if ((ptr+i)->valid == 1 && (ptr+i)->tag == tag)
        {
            isMiss = 0;
            updateLRU(cache, set, i);
        }
    } 
    return isMiss;
}

//访问后更新当前set 
int updateCache(cacheline *cache, int set, int tag)
{
    cacheline *ptr = cache + set * E;
    for (int i = 0; i < E; ++i)
    {
        if ((ptr+i)->valid == 0)
        {
            (ptr+i)->valid = 1;
            (ptr+i)->tag = tag;
            updateLRU(cache, set, i);
            return 0;
        }
    }
    int evictIndex = findMinLRU(cache, set);
    ptr = ptr + evictIndex;
    ptr->valid = 1;
    ptr->tag = tag;
    updateLRU(cache, set, evictIndex);
    return 1;
}

//模拟加载和存储操作，两者实际相同 
void LoadOrStore(cacheline *cache, int set, int tag, int verboseflag)
{
    if (isMiss(cache, set, tag))
    {
        ++miss_count;
        if (verboseflag) printf(" miss");
        if (updateCache(cache, set, tag))
        {
            ++evict_count;
            if (verboseflag) printf(" eviction");
        }
    }
    else
    {
        ++hit_count;
        if (verboseflag) printf(" hit");
    }
}

//模拟更改操作，相当于一读一写 
void modify(cacheline *cache, int set, int tag, int verboseflag)
{
    LoadOrStore(cache, set, tag, verboseflag);
    LoadOrStore(cache, set, tag, verboseflag);
}

//主函数，用命令行参数 
int main(int argc, char *argv[])
{
    int sbits = 0;
    int bbits = 0;
    int verboseflag = 0;
    int op = -1;
    char *tracefile = NULL;
    while ((op = getopt(argc, argv, "s:E:b:t:hv")) != -1)
    {
        switch(op)
        {
            case 's': 
                sbits = atoi(optarg); 
                S = 2 << sbits; 
                break;
            case 'E': 
                E = atoi(optarg);
                break;
            case 'b': 
                bbits = atoi(optarg);
                B = 2 << bbits;
                break;
            case 't': 
                tracefile = optarg;
                break;
            case 'v': 
                verboseflag = 1;
                break;
            case 'h':
            default:
                 print_help();
                 exit(0);
                break;
        }
    }
    FILE *fp = fopen(tracefile, "r");
    if (fp == NULL)
    {
        printf("File opening failed");
        exit(0);
    }
    mycache = (cacheline *)malloc(S * E * sizeof(cacheline));
    if (mycache == NULL)
    {
        printf("memory allocation failed");
        exit(0);
    }
    char oper;
    long addr;
    int size;
    while(fscanf(fp, " %c %lx,%d", &oper, &addr, &size) != EOF )
    {
        if (oper != 'I')
        {
            int set = get_set(addr, sbits, bbits);
            int tag = get_tag(addr, sbits, bbits);
            if (verboseflag) 
                printf("%c %lx,%d", oper, addr, size);
            if (oper == 'S' || oper == 'L')
                LoadOrStore(mycache, set, tag, verboseflag);
            else
                modify(mycache, set, tag, verboseflag);
            if (verboseflag) 
                printf("\n");
        }
    }
    printSummary(hit_count, miss_count, evict_count);
    return 0;
}
