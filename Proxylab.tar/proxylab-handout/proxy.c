/*
	吴润迪 1600012806
	主要参照书本上的样例进行扩展
	cache分成了10个block来处理
*/
#include <stdio.h>
#include "csapp.h"

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400
#define MAX_CACHE_BLOCKNUM 10

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";
static const char *conn_hdr = "Connection: close\r\n";
static const char *proxy_hdr = "Proxy-Connection: close\r\n";

struct Cache_block
{
	char data[MAX_OBJECT_SIZE];
	char url[MAXLINE];
	int LRU;
	int read_cnt;
	int is_used;
	sem_t w_mutex;		/* protect this block region */
	sem_t cnt_mutex;	/* protect read_cnt */
}cache_block[MAX_CACHE_BLOCKNUM];

/* helper functions */
void doit(int fd);
void parse_uri(char *uri, char *hostname, char *filepath, char *server_port);
void read_requesthdrs(char *request, char *hostname, 
						char *filepath, rio_t *client_rio);
void *thread(void *vargp);
void init_cache();
void before_read(int i);
void after_read(int i);
void before_write(int i);
void after_write(int i);
int find_in_cache(char *url);
int find_block();
void write_to_cache(char *url, char *data);
void update_LRU(int index);

int main(int argc, char *argv[])
{
	int listenfd, *connfd;
	char hostname[MAXLINE], port[MAXLINE];
	socklen_t clientlen;
	struct sockaddr_storage clientaddr;
	pthread_t tid;

	if (argc != 2)
	{
		fprintf(stderr, "usage: %s <port>\n", argv[0]);
		exit(1);
	}

	init_cache();
	Signal(SIGPIPE, SIG_IGN);
	listenfd = Open_listenfd(argv[1]);
	while(1)
	{
		clientlen = sizeof(clientaddr);
		/*connect with client*/
		connfd = Malloc(sizeof(int));
		*connfd = Accept(listenfd, (SA*)&clientaddr, &clientlen);
		Getnameinfo((SA*)&clientaddr, clientlen, 
			hostname, MAXLINE, port, MAXLINE, 0);
		printf("Accepted connection from (%s, %s)\n", hostname, port);
		Pthread_create(&tid, NULL, thread, connfd);
	}

    return 0;
}

/* Thread routiue */
void *thread(void *vargp)
{
	int connfd = *((int *)vargp);
	Pthread_detach(pthread_self());
	Free(vargp);
	doit(connfd);
	Close(connfd);
	return NULL;
}
/* handle client connection and request */
void doit(int connfd)
{
	char buf[MAXLINE], method[MAXLINE], uri[MAXLINE], version[MAXLINE];
	char hostname[MAXLINE], filepath[MAXLINE], server_port[MAXLINE];
	char rebuilt_request[MAXLINE];
	int serverfd;
	size_t n;
	rio_t client_rio, server_rio;

	/* read client's request line */
	Rio_readinitb(&client_rio, connfd);
	Rio_readlineb(&client_rio, buf, MAXLINE);
	printf("Request line: %s\n", buf);
	sscanf(buf,"%s %s %s", method, uri, version);
	if (strcasecmp(method, "GET"))
	{
		printf("This proxy do not implement such method\n");
		return;
	}

	/* parse the uri */
	parse_uri(uri, hostname, filepath, server_port);
	/* read_requsthdr and rebulid request */
	read_requesthdrs(rebuilt_request, hostname, filepath, &client_rio);
	//printf("rebuilt_request = %s\n", rebuilt_request);

	char url_ori[MAXLINE];
	sprintf(url_ori, "%s:%s%s", hostname, server_port, filepath);
	int cache_index = find_in_cache(url_ori);
	if (cache_index != -1)
	{
		before_read(cache_index);
		Rio_writen(connfd, cache_block[cache_index].data, 
					strlen(cache_block[cache_index].data));
		after_read(cache_index);
		printf("already in cache!\n");
		return;
	}

	/* connect to server */
	if ((serverfd = Open_clientfd(hostname, server_port)) < 0)
	{
		//printf("connection to server failed\n");
		return;
	}

	Rio_readinitb(&server_rio, serverfd);
	Rio_writen(serverfd, rebuilt_request, strlen(rebuilt_request));

	/* after recieve data from server, try to store it in cache */
	char data[MAX_OBJECT_SIZE];
	int data_size = 0;
	while ((n = Rio_readlineb(&server_rio, buf, MAXLINE)) != 0)
	{
		data_size += n;
		printf("proxy get %d bytes from server,then send to client\n",(int)n);
		if (data_size < MAX_OBJECT_SIZE)
			strcat(data, buf);
		Rio_writen(connfd, buf, n);
	}
	Close(serverfd);
	
	if (data_size < MAX_OBJECT_SIZE)
	{
		write_to_cache(url_ori, data);
	}
}

/* parse uri to get server's hostname, filepath and port */
void parse_uri(char *uri, char *hostname, char *filepath, char *server_port)
{
	char *pos1, *pos2;
	int port = 80;			//default port number

	pos1 = strstr(uri, "//");
	if (pos1 == NULL)
		pos1 = uri;
	else 
		pos1 += 2;

	pos2 = strstr(pos1, ":");
	if (pos2 == NULL)		// if there is no port numeber
	{
		pos2 = strstr(pos1, "/");
		if (pos2 == NULL)   // if no filepath
		{
			sscanf(pos1, "%s", hostname);
			sprintf(filepath, "/");
		}
		else
		{
			*pos2 = '\0';
			sscanf(pos1, "%s", hostname);
			*pos2 = '/';
			sscanf(pos2, "%s", filepath);
			if (*(pos2+1) == '~')
				strcat(filepath, "/");
		}
	}
	else
	{
		*pos2 = '\0';
		sscanf(pos1, "%s", hostname);
		sscanf(pos2 + 1, "%d%s", &port, filepath);
	}
	sprintf(server_port, "%d", port);

	return;
}

void read_requesthdrs(char *request, char *hostname, 
					char *filepath, rio_t *client_rio)
{
	char buf[MAXLINE], request_line[MAXLINE];
	char host_hdr[MAXLINE], other_hdr[MAXLINE];
	/* rebulid request line */
	sprintf(request_line, "GET %s HTTP/1.0\r\n", filepath);
	/* read client request header and rebulid it */
	Rio_readlineb(client_rio, buf, MAXLINE);
	while (strcmp(buf, "\r\n"))
	{
		if (buf != NULL && strncasecmp(buf, "Host:", 5) == 0)
		{
			strcpy(host_hdr, buf);
			if (strlen(hostname) == 0)
				sscanf(buf, "Host: %s\r\n", hostname);
		}
		else if (buf != NULL && (strncasecmp(buf, "User-Agent:", 11) != 0)
			&& (strncasecmp(buf, "Connection:", 11) != 0) 
			&& (strncasecmp(buf, "Proxy-Connection:", 17) != 0))
		{
			strcat(other_hdr, buf);
		}
		Rio_readlineb(client_rio, buf, MAXLINE);
	}
	if (strlen(host_hdr) == 0)
		sprintf(host_hdr, "Host: %s\r\n", hostname);
	sprintf(request, "%s%s%s%s%s%s%s", request_line, host_hdr, 
		user_agent_hdr, conn_hdr, proxy_hdr, other_hdr, "\r\n");
	return;
}


/* cache part */

void init_cache()
{
	int i;
	for (i = 0; i < MAX_CACHE_BLOCKNUM; ++i)
	{
		cache_block[i].LRU = 0;
		cache_block[i].read_cnt = 0;
		cache_block[i].is_used = 0;
		Sem_init(&cache_block[i].w_mutex, 0, 1);
		Sem_init(&cache_block[i].cnt_mutex, 0, 1);
	}
}

void before_read(int i)
{
	P(&cache_block[i].cnt_mutex);
	++cache_block[i].read_cnt;
	if(cache_block[i].read_cnt == 1) P(&cache_block[i].w_mutex);
	V(&cache_block[i].cnt_mutex);
}

void after_read(int i)
{	
	P(&cache_block[i].cnt_mutex);
	--cache_block[i].read_cnt;
	if (cache_block[i].read_cnt == 0) V(&cache_block[i].w_mutex);
	V(&cache_block[i].cnt_mutex);
}

void before_write(int i)
{
	P(&cache_block[i].w_mutex);
}

void after_write(int i)
{
	V(&cache_block[i].w_mutex);
}

/* check if url is stored in cacheblock */
int find_in_cache(char *url)
{
	int i = -1;
	for (i = 0; i < MAX_CACHE_BLOCKNUM; ++i)
	{
		before_read(i);
		if ((cache_block[i].is_used == 1) 
			&& (strcmp(cache_block[i].url, url) == 0))
		{
			after_read(i);
			break;
		}
		after_read(i);
	}
	if (i < MAX_CACHE_BLOCKNUM)
		return i;
	else
		return -1;
}

/* find proper cacheblock that can be written */
int find_block()
{
	int index = -1, i;
	int maxLRU = 0;
	for (i = 0;i < MAX_CACHE_BLOCKNUM; ++i)
	{
		before_read(i);
		if (cache_block[i].is_used == 0)
		{
			index = i;
			after_read(i);
			break;
		}
		if (cache_block[i].LRU > maxLRU)
		{
			index = i;
			maxLRU = cache_block[i].LRU;
			after_read(i);
			continue;
		}
		after_read(i);
	}
	return index;
}

/* write (url, data) to cacheblock */
void write_to_cache(char *url, char *data)
{
	int index = find_block();
	before_write(index);
	strcpy(cache_block[index].data, data);
	strcpy(cache_block[index].url, url);
	cache_block[index].is_used = 1;
	cache_block[index].LRU = 0;
	after_write(index);
	update_LRU(index);
}

/* update cacheblock's LRU except block[index] */
void update_LRU(int index)
{
	int i;
	for (i = 0; i < MAX_CACHE_BLOCKNUM; ++i)
	{
		if (i == index) continue;
		before_read(i);
		if ((cache_block[i].is_used == 1) && (i != index))
		{
			after_read(i);
			before_write(i);
			cache_block[i].LRU++;
			after_write(i);
			continue;
		}
		after_read(i);
	}
}
